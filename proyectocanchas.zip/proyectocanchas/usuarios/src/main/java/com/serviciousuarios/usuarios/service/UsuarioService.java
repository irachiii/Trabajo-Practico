package com.serviciousuarios.usuarios.service;

import java.util.List;

import com.serviciousuarios.usuarios.model.Usuario;

public interface UsuarioService {

    List<Usuario> listaUsuarios();

    Usuario crearUsuario(Usuario usuario);

    Usuario buscarUsuario (Long id);
    
}
