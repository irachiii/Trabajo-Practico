package com.serviciousuarios.usuarios.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.serviciousuarios.usuarios.model.Usuario;

public interface UsuarioRepository extends JpaRepository <Usuario, Long> {
}
